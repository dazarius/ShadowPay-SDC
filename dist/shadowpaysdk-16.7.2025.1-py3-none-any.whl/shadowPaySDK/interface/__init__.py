from .erc20 import ERC20Token as ERC20
from .erc721 import ERC721Token as ERC721
from .sol import SOL as sol
__all__ = ["ERC20", "ERC721", "sol"]
