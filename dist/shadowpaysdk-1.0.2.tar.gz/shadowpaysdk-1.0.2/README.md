# shadowPaySdk

```bash
pip3 install shadowPaySDK
pip3 install --break-system-packages git+https://github.com/dazarius/SDK.git
```
```example to use cheque





import shadowPaySDK


EVMcheque = shadowPaySDK.Cheque(
    retunrn_build_tx=True
)



