# shadowPayS

```bash
pip3 install shadowPaySDK
```
```example to use cheque





import shadowPaySDK


EVMcheque = shadowPaySDK.Cheque(
    retunrn_build_tx=True
)



